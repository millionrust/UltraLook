export const Header = () => <header>Studio North</header>;
