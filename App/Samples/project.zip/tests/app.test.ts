import app from "../src/app";
test("app", () => expect(app).toBeDefined());
